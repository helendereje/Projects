from door import Door
from random import randint

class ComboDoor(Door):
	"""
	Attributes:
		_correct_value: int
		_input: int
	"""
	def __init__(self):
		"""
		randomize the value to a number 1-10.
		"""
		self._correct_value = randint(1, 10)
		self._input = None

	def examine_door(self):
		return "You encounter a door with a combination lock." + "\n" + "Enter a number from 1 to 10 to unlock it."

	def menu_options(self):
		return "Enter # 1-10: "

	def get_menu_max(self):
		return 10

	def attempt(self, option):
		self._input = option
		return f"You turn the dial to {option}."

	def is_unlocked(self):
		return self._input == self._correct_value

	def clue(self):
		if self._input > self._correct_value:
			return "Try a lower number."
		else:
			return "Try a higher number."

	def success(self):
		return "You found the correct value and opened the door."