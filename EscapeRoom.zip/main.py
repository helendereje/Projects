# Author: Daphne Rios, Helen Dereje
# Date: October 19, 2023
# Description: 	a program that simulates an escape room by having the user open a series of three doors 
# 				randomly chosen from several different types of doors.

from basic_door import BasicDoor
from locked_door import LockedDoor
from deadbolt_door import DeadboltDoor
from combo_door import ComboDoor
#from code_door import CodeDoor
from checkinput import get_int_range
from random import choice, randint

def open_door(a_door):
	"""
	passes in a door object that the user will try to unlock. 
	It displays the description of the door, and the menu, then gets the user’s selection, 
	then passes that value to the attempt method and display the result. 
	If the attempt was successful, then it displays the success message, 
	otherwise, it displays the clue message and repeat from the menu until the user successfully opens the door.
	"""
	loop = True
	#user examines the door
	print(a_door.examine_door())

	#loop until user unlocks & opens door
	while loop:
		#display menu for the door
		print(a_door.menu_options(), end = "")
		
		#get user input
		if not isinstance(a_door, ComboDoor):
			user_choice = get_int_range("\n" + "> ", 1, a_door.get_menu_max())
		else:
			user_choice = get_int_range("", 1, a_door.get_menu_max())
		print()

		#user attempts to open door
		print(a_door.attempt(user_choice))

		#user opens door or it's still locked
		if a_door.is_unlocked():
			print(a_door.success())
			loop = False
		else:
			print(a_door.clue())
		print("="*70)

def main():
	"""
	has a loop that repeats three times for the three doors that the user will try to open. 
	Randomly chooses a door from the ones that are implemented and passes it to open_door. 
	After the user has opened all three doors, then display a congratulatory message and end the game.
	"""
	#welcome message to the user
	print("Welcome to the Escape Room.")
	print("You must unlock 3 doors to escape...")
	print("="*70)

	#go thru a random door 3 times
	for _ in range(3):
		door_num = randint(1, 4)
		
		if door_num == 1:
			open_door(BasicDoor())
		elif door_num == 2:
			open_door(LockedDoor())
		elif door_num == 3:
			open_door(DeadboltDoor())
		elif door_num == 4:
			open_door(ComboDoor())
		else: #in case door_num is invalid, open a basic door
			open_door(BasicDoor())
		
	#user has gone thru all the doors, congrutaltions are in order
	print("Congratulations! You escaped...this time.")

main()