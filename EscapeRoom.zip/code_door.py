#Doesn't work

from random import choice
from door import Door

class CodeDoor(Door):
	"""
	Attributes:
		_correct_code: char[]
		_input: char[]
	"""
	def __init__(self):
		"""
		randomize each of the characters in the code as an ‘X’ or ‘O’.
		"""
		self._correct_code = [choice(["X" ,"O"]) for _ in range(self.get_menu_max())]
		self._input = ["X", "X", "X"]

	def examine_door(self) -> str:
		return "A door with a coded keypad with three characters." + "\n" + "Each key toggles a value with an ‘X’ or an ‘O’."

	def menu_options(self) -> str:
		return "1. Press Key 1" + "\n" + "2. Press Key 2" + "\n" + "3. Press Key 3"

	def get_menu_max(self) -> int:
		return 3

	def attempt(self ,option) -> str:
		phrase = "You press the key {}"
		if option == 1:
			self._input[0] = "O" if self._input[0] == "X" else "X"
			return phrase.format("1")
		elif option == 2:
			self._input[1] = "O" if self._input[1] == "X" else "X"
			return phrase.format("2")
		else:
			self._input[2] = "O" if self._input[2] == "X" else "X"
			return phrase.format("3")

	def clue(self) -> str:
		correct = []
		position = ["first" ,"second" ,"third"]
		if self._input != self._correct_code:
			for idx ,char in enumerate(self._input):
				if char in self._correct_code:
					correct.append(f"{position[idx]}")
		if correct:
			return "The {} index are correct".format(", ".join(correct))

	def is_unlocked(self) -> bool:
		return self._input == self._correct_code

	def success(self):
		return "You cracked the code and opened the door."
