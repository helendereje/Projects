from door import Door
from random import randint

class DeadboltDoor(Door):
	"""
	Attributes:
		_bolt1: int
		_bolt2: int
	"""
	def __init__(self):
		"""
		Randomizes the state of the two bolts (either locked or unlocked)
		"""
		self._bolt1 = randint(1, self.get_menu_max())
		self._bolt2 = randint(1, self.get_menu_max())

	def examine_door(self):
		return "A door with two deadbolts." + "\n" + "Both need to be unlocked to open the door, " + "\n" + "but you can’t tell if each one is locked or unlocked."
	
	def menu_options(self):
		return "1. Toggle bolt 1" + "\n" + "2. Toggle bolt 2"

	def get_menu_max(self):
		return len(self.menu_options().splitlines())

	def attempt(self, option):
		if option == 1:
			self._bolt1 = 1
			return "You toggle the first bolt."
		else:
			self._bolt2 = 1
			return "You toggle the second bolt."

	def is_unlocked(self):
		return (self._bolt1 == self._bolt2)

	def clue(self):
		if self._bolt1 == 1 or self._bolt2 == 1:
			return "You jiggle the door... it seems like one of the bolts is unlocked."
		elif self._bolt1 == 2 and self._bolt2 == 2:
			return "You jiggle the door... it seems like it’s completely locked."
		else:
			return "The state of this deadbolted door is a complete mystery."

	def success(self):
		return "You unlocked both deadbolts and opened the door"