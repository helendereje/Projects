from door import Door
from random import randint

class BasicDoor(Door):
	def __init__(self):
		self._state = randint(1, self.get_menu_max())
		self._input = None

	def examine_door(self):
		return "You encounter a door, you can either push it or pull it to open."

	def menu_options(self):
		return "1. Push" + "\n" + "2. Pull"

	def get_menu_max(self):
		return len(self.menu_options().splitlines())

	def attempt(self, option):
		self._input = option
		if option == 1:
			return "You push the door"
		else:
			return "You pull the door"

	def is_unlocked(self):
		return (self._input == self._state)

	def clue(self):
		return "Try the other way."

	def success(self):
		if self.is_unlocked():
			return "Congratulations, you opened the door."
		else:
			return "The door doesn't open."