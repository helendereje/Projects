from door import Door
from random import randint

class LockedDoor(Door):
	"""
	Attributes:
		_key_location: init
		_input: int
	"""
	def __init__(self):
		"""
		randomizes the location of the key.
		"""
		self.key_location = randint(1, self.get_menu_max())

	def examine_door(self):
		return "A locked door." + "\n" + "Look around for the key."

	def menu_options(self):
		return "1. Look under the mat" + "\n" + "2. Look under the flower pot" + "\n" + "3. Look under the fake rock."

	def get_menu_max(self):
		return len(self.menu_options().splitlines())

	def attempt(self, option):
		self.input = option
		if self.input == 1:
			return "You look under the mat."
		elif self.input == 2:
			return "You look under the flower pot."
		else:
			return "You look under the fake rock."

	def is_unlocked(self):
		return self.input == self.key_location

	def clue(self):
		return "Look somewhere else..."

	def success(self):
		if self.is_unlocked():
			return "You found the key and opened the door."
		else:
			return "The door doesn't open."