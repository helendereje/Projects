import random
from card import Card

class Deck:
    def __init__(self):
        self._cards = [Card(suit, rank) for suit in Card.SUITS for rank in Card.RANKS]

    def shuffle(self):
        random.shuffle(self._cards)

    def draw_card(self):
        return self._cards.pop()

    def __len__(self):
        return len(self._cards)
