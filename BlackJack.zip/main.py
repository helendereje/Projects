# Author: Daphne Rios, Helen Dereje
# Date: October 5, 2023

from card import Card
from deck import Deck
from player import Player
from dealer import Dealer

def display_winner(pScore, dScore, points):
    if pScore > 21:
        print("Player busts! Dealer wins.")
        points[1] += 1
    elif dScore > 21:
        print("Dealer busts! Player wins.")
        points[0] += 1
    elif pScore > dScore:
        print("Player wins.")
        points[0] += 1
    elif pScore < dScore:
        print("Dealer wins.")
        points[1] += 1
    else:
        print("Tie!")

    print(f"Player's points: {points[0]}")
    print(f"Dealer's points: {points[1]}")

def main():
    print("-Blackjack-")
    points = [0, 0]

    while True:
        deck = Deck()
        deck.shuffle()

        player = Player(deck)
        dealer = Dealer(deck)

        print("Player's Cards:")
        print(player)

        while True:
            choice = input("1. Hit\n2. Stay\nEnter choice: ")
            if choice == '1':
                player.hit()
                print(player)
                if player.score() > 21:
                    print("Bust!")
                    break
            elif choice == '2':
                break

        dealer.play()
        print("Dealer's Cards:")
        print(dealer)

        display_winner(player.score(), dealer.score(), points)

        play_again = input("Play again? (Y/N): ")
        if play_again.lower() != 'y':
            break

if __name__ == "__main__":
    main()
