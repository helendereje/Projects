from card import Card
from deck import Deck

class Player:
    def __init__(self, deck):
        self._deck = deck
        self._hand = []

        for _ in range(2):
            self._hand.append(self._deck.draw_card())
        self._hand.sort()

    def hit(self):
        card = self._deck.draw_card()
        self._hand.append(card)
        self._hand.sort()

    def score(self):
        total_score = 0
        num_aces = 0

        for card in self._hand:
            if card.rank in ['Jack', 'Queen', 'King']:
                total_score += 10
            elif card.rank == 'Ace':
                total_score += 11
                num_aces += 1
            else:
                total_score += int(card.rank)

        while num_aces > 0 and total_score > 21:
            total_score -= 10
            num_aces -= 1

        return total_score

    def __str__(self):
        return '\n'.join(map(str, self._hand)) + f'\nScore = {self.score()}'
