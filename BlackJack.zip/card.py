class Card:
    RANKS = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', 'King', 'Ace']
    SUITS = ['Clubs', 'Diamonds', 'Hearts', 'Spades']

    def __init__(self, suit, rank):
        self._rank = rank
        self._suit = suit

    @property
    def rank(self):
        return self._rank

    def __str__(self):
        return f'{self._rank} of {self._suit}'

    def __lt__(self, other):
        return self.RANKS.index(self._rank) < self.RANKS.index(other._rank)
