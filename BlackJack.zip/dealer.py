from player import Player

class Dealer(Player):
    def play(self):
        while self.score() <= 16:
            self.hit()
